package com.example.chatbot

 data class MessageViewModel (
     var message:  String,
     var sender:   String
 )